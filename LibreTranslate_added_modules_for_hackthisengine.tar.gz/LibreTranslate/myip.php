<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html>
<head>
<title>when used not seen in hidden text</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>

<frameset framespacing="0" frameborder="0" rows="0,*">
<frame name="statsframe" id="statsframe" frameborder="0" scrolling="auto" src="/dy-fi-stats-frame" noresize="noresize" />
<frame name="offlineframe" id="offlineframe" frameborder="0" scrolling="auto" src="https://datat.freehostia.com/myip.php" />
<noframes>
	<body>
	<a href="https://datat.freehostia.com/myip.php">Selaimesi ei ilmeisesti tue kehyksiä - paina tätä linkkiä jatkaaksesi sivulle.<br />
	It would seem that your browser does not support frames, please click on this link instead.</a>
	</body>
</noframes>
</frameset>
</html>

